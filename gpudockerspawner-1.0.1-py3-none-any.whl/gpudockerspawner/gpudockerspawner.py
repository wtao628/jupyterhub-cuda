"""A DockerSpawner that can manage GPUs."""

import inspect
import os

import docker

from dockerspawner import DockerSpawner
from traitlets import default, List


def _deep_merge(dest, src):
    for key, value in src.items():
        if key in dest:
            dest_value = dest[key]
            if isinstance(dest_value, dict) and isinstance(value, dict):
                dest[key] = _deep_merge(dest_value, value)
            else:
                dest[key] = value
        else:
            dest[key] = value

    return dest


class GPUDockerSpawner(DockerSpawner):
    """
    An extension of the DockerSpawner that provides one GPU to a user on a
    first come, first served basis.

    Attributes
    ----------
    gpu_notebooks : list
        A list of GPU-accelerated container images.
    reserved_gpu : str
        The ID of the GPU that is being used for the user's container.

    Methods
    -------
    create_object()
        Creates the container.
    stop(now=False)
        Stops the container.
    """

    gpu_notebooks = List([], config=True, help="""A list of GPU-accelerated
                         container images.""")
    reserved_gpu: str

    @default("options_form")
    def _default_options_form(self):
        allowed_images = self._get_allowed_images()

        if len(allowed_images) == 0:
            return ""

        option_t = '<option value="{image}" {selected}>{image}</option>'
        options = [
            option_t.format(
                image=image, selected="selected" if image == self.image else ""
            )
            for image in allowed_images
        ]
        return """
        <label for="image">Select an image:</label>
        <select class="form-control" name="image" required autofocus>
        {options}
        </select>
        """.format(options=options)

    async def create_object(self):
        """Creates the container."""
        gpus = [*os.environ["GPUS"]]

        if len(gpus) == 0 and self.image in self.gpu_notebooks:
            # Return back to options screen
            self._default_options_form()
        elif self.image in self.gpu_notebooks:
            # Create GPU-acclereated container and assign GPU
            create_kwargs = dict(image=self.image,
                                 environment=self.get_env(),
                                 volumes=self.volume_mount_points,
                                 name=self.container_name,
                                 command=(await self.get_command())
                                 )
            self.extra_host_config["device_requests"] = [docker.types.DeviceRequest(device_ids=[gpus[0]], capabilities=[["gpu"]])]
            os.environ["GPUS"] = "".join(gpus[1:])
            self.reserved_gpu = gpus[0]
        else:
            create_kwargs = dict(image=self.image,
                                 environment=self.get_env(),
                                 volumes=self.volume_mount_points,
                                 name=self.container_name,
                                 command=(await self.get_command())
                                 )

        extra_create_kwargs = self._eval_if_callable(self.extra_create_kwargs)
        if inspect.isawaitable(extra_create_kwargs):
            extra_create_kwargs = await extra_create_kwargs
        extra_create_kwargs = self._render_templates(extra_create_kwargs)

        extra_host_config = self._eval_if_callable(self.extra_host_config)
        if inspect.isawaitable(extra_host_config):
            extra_host_config = await extra_host_config
        extra_host_config = self._render_templates(extra_host_config)

        # Ensure internal port is exposed
        create_kwargs["ports"] = {"%i/tcp" % self.port: None}

        _deep_merge(create_kwargs, extra_create_kwargs)

        # Build the dictionary of keyword arguments for host_config
        host_config = dict(
            auto_remove=self.remove,
            binds=self.volume_binds,
            links=self.links,
            mounts=self.mount_binds,
        )

        if getattr(self, "mem_limit", None) is not None:
            host_config["mem_limit"] = self.mem_limit

        if getattr(self, "cpu_limit", None) is not None:
            # Docker CPU units are in microseconds
            # cpu_period default is 100ms
            # cpu_quota is cpu_period * cpu_limit
            cpu_period = host_config["cpu_period"] = extra_host_config.get(
                "cpu_period", 100_000
            )
            host_config["cpu_quota"] = int(self.cpu_limit * cpu_period)

        if not self.use_internal_ip:
            host_config["port_bindings"] = {self.port: (self.host_ip,)}
        _deep_merge(host_config, extra_host_config)
        host_config.setdefault("network_mode", self.network_name)

        self.log.debug("Starting host with config: %s", host_config)

        host_config = self.client.create_host_config(**host_config)
        create_kwargs.setdefault("host_config", {}).update(host_config)

        # Create the container
        obj = await self.docker("create_container", **create_kwargs)
        return obj

    async def stop(self, now=False):
        """Stops the container."""
        self.log.info(
            "Stopping %s %s (id: %s)",
            self.object_type,
            self.object_name,
            self.object_id[:7],
        )
        await self.stop_object()

        if self.remove:
            await self.remove_object()
            # Clear object_id to avoid persisting removed state
            self.object_id = ""

        if os.environ["GPUS"] == "" and self.image in self.gpu_notebooks:
            os.environ["GPUS"] = self.reserved_gpu
        else:
            os.environ["GPUS"] += self.reserved_gpu

        self.clear_state()
